import React, { useId } from "react";
import { cn } from "../utils/cn";

function CustomInput({
  label,
  
  inputProps: { type = "text", className, ...ipProps } = {},
  rtl,
}) {

  const uniqueId = useId();

  return (
    <div
      className={cn("flex items-center gap-5 max-w-max", rtl ? "flex-row-reverse" : "")}
    >
      <label htmlFor={uniqueId} className="text-sm text-gray-700">{label}</label>
      <input id={uniqueId} type={type} className={cn("border-2 rounded-sm px-2 border-gray-[#cccccc] w-96 h-9 rounded-sms", className)} {...ipProps} />
    </div>
  );
}

export default CustomInput;
