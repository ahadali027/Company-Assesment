import React, { useState } from "react";

import SectionWrapper from "../components/SectionWrapper";
import FormHeader from "../components/FormHeader";
import CustomInput from "../components/CustomInput";
import SearchableDropdownExample from "../components/DropDownSearchBox";

function Form() {
  const [companyType, setCompanyType] = useState("");
  const [form, setForm] = useState({
    careOf: "",
    unit: "",
    streetAddress: "",
    suburb: "",
    state: "",
    postCode: "",
    country: "Australia",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const companyOptions = [
    "Private Limited",
    "Public Limited",
    "Sole Proprietorship",
    "Partnership",
    "LLC",
  ];
  return (
    <div className="px-10 mt-3">
      <form action="">
        <div>
          <FormHeader heading="Please provide your email address for document delivery purposes" />
          <div className="grid grid-cols-2 i">
            <div className="flex flex-col gap-5 mt-3">
              <CustomInput
                label="Email Addess"
                inputProps={{ className: "ml-10" }}
              />
              <CustomInput label="Confirm Email Addess" inputProps={{}} />
            </div>
          </div>
        </div>
        <div className="mt-8">
          <FormHeader heading="Do you have a proposed name for your company?" />
          <div className="grid grid-cols-2 gap-5 items-center">
            <div className="flex flex-col  mt-3">
              <CustomInput
                rtl
                label="Yes"
                inputProps={{ type: "radio", className: "w-4" }}
              />
              <CustomInput
                rtl
                label="No"
                inputProps={{ type: "radio", className: "w-4" }}
              />
            </div>
            <div>
              <p className="text-sm text-[#515151] max-w-2xl ">
                If you tick “No”, a company will have an automatically generated
                number assigned by ASIC to its name i.e. 987 789 987 Pty Ltd.
              </p>
            </div>
          </div>
        </div>
        <div>
          <FormHeader heading="How do you wish your Proprietary Limited to be described?" />
          <div className="grid grid-cols-2 gap-5 items-center">
            <div className="flex flex-col gap-5 mt-3">
              <CustomInput
                label="Proposed Name"
                inputProps={{
                  className: "ml-10 text-sm text-gray-700",
                  placeholder: "ENTER YOUR COMPANY PROPRIETARY NAME",
                }}
              />
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-700">Type of Company</label>
                <select
                  value={companyType}
                  onChange={(e) => setCompanyType(e.target.value)}
                  className="border w-full max-w-sm focus:outline-none focus:ring-2 focus:ring-blue-300 px-4 py-2 shadow-sm text-gray-700"
                >
                  <option value="" disabled></option>
                  {companyOptions.map((option, idx) => (
                    <option key={idx} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <p className="text-sm text-[#515151] max-w-2xl ">
                ASIC requires company names to be in capital letters (company
                name only excluding PTY LTD).
              </p>
            </div>
          </div>
        </div>
        <div className="mt-8">
          <FormHeader heading="Is your company name the same as your registered business name?" />
          <div className="grid grid-cols-2 gap-5 items-center">
            <div className="flex flex-col  mt-3">
              <CustomInput
                rtl
                label="Yes"
                inputProps={{ type: "radio", className: "w-4" }}
              />
              <CustomInput
                rtl
                label="No"
                inputProps={{ type: "radio", className: "w-4" }}
              />
            </div>
            <div>
              <p className="text-sm text-[#515151] max-w-2xl mt-2">
                If you are a sole trader and own a business name and wish to set
                up a company with the same business name, please enter your
                Australian Business Number (ABN) – for business names registered
                with ASIC after 28th May 2012. Alternatively please enter your
                state business number if you wish to transfer the business name
                to a company (for registrations before 28th May 2012)
              </p>
            </div>
          </div>
        </div>
        <div className="mt-8">
          <FormHeader heading="I am interested in obtaining a free quote for Website Design or SEO Marketing services from an Aussie based specialist." />
          <div className="grid grid-cols-2 gap-5 items-center">
            <div className="flex flex-col  mt-3">
              <CustomInput
                rtl
                label="Yes"
                inputProps={{ type: "radio", className: "w-4" }}
              />
              <CustomInput
                rtl
                label="No"
                inputProps={{ type: "radio", className: "w-4" }}
              />
            </div>
            <div>
              <p className="text-sm text-[#515151] max-w-2xl mt-2">
                SEO & Online Marketing help local business to rank higher and
                obtain more traffic from Google to acquire more customers and
                grow their business via the internet. Take the first step to
                grow and expand your business today by speaking to an Aussie
                based specialist .
              </p>
            </div>
          </div>
        </div>
        <div className="mt-8">
          <FormHeader heading="Would you like Xero Accounting subscription at 90% Off retail price?" />
          <div className="grid grid-cols-2 gap-5 items-center">
            <div className="flex flex-col  mt-3">
              <CustomInput
                rtl
                label="Yes"
                inputProps={{ type: "radio", className: "w-4" }}
              />
              <CustomInput
                rtl
                label="No"
                inputProps={{ type: "radio", className: "w-4" }}
              />
            </div>
            <div></div>
          </div>
        </div>
        <div className="mt-8">
          <FormHeader heading="Has your company name been reserved with ASIC?" />
          <div className="grid grid-cols-2 gap-5 items-center">
            <div className="flex flex-col  mt-3">
              <CustomInput
                rtl
                label="Yes"
                inputProps={{ type: "radio", className: "w-4" }}
              />
              <CustomInput
                rtl
                label="No"
                inputProps={{ type: "radio", className: "w-4" }}
              />
            </div>
            <div>
              <p className="text-sm text-[#515151] max-w-2xl mt-2">
                A company name may be reserved before it is registered with
                ASIC. If you reserved the name with ASIC previously please enter
                a reservation number, otherwise select No to the question.
              </p>
            </div>
          </div>
        </div>
        <div>
          <FormHeader heading="Please select which State/Territory you wish to register the company in?" />
          <div className="grid grid-cols-2 gap-5 items-center">
            <div className="flex flex-col gap-5 mt-3">
              <div className="flex items-center gap-5 justify-center">
                <label className="text-sm text-gray-700">State</label>
                <select
                  value={companyType}
                  onChange={(e) => setCompanyType(e.target.value)}
                  className="border w-full max-w-sm focus:outline-none focus:ring-2 focus:ring-blue-300 px-4 py-2 shadow-sm text-gray-700"
                >
                  <option value="" className="text-sm text-gray-700" disabled>
                    List of States
                  </option>
                  {companyOptions.map((option, idx) => (
                    <option key={idx} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div></div>
          </div>
        </div>
        <div className="mt-8">
          <FormHeader heading="Will the company be acting only as a trustee of a Self Managed Super Fund (SMSF)?" />
          <div className="grid grid-cols-2 gap-5 items-center">
            <div className="flex flex-col  mt-3">
              <CustomInput
                rtl
                label="Yes"
                inputProps={{ type: "radio", className: "w-4" }}
              />
              <CustomInput
                rtl
                label="No"
                inputProps={{ type: "radio", className: "w-4" }}
              />
            </div>
            <div>
              <p className="text-sm text-[#515151] max-w-2xl mt-2">
                Annual registration fees vary for trustee companies of SMSFs
                compared to standard pty ltd companies.
              </p>
            </div>
          </div>
        </div>
        <div className="mt-8">
          <FormHeader heading="Will the company have an ultimate holding company?" />
          <div className="grid grid-cols-2 gap-5 items-center">
            <div className="flex flex-col  mt-3">
              <CustomInput
                rtl
                label="Yes"
                inputProps={{ type: "radio", className: "w-4" }}
              />
              <CustomInput
                rtl
                label="No"
                inputProps={{ type: "radio", className: "w-4" }}
              />
            </div>
            <div></div>
          </div>
        </div>
        <div className="mt-8">
          <FormHeader
            heading="Please enter a registered address for the company."
            subHeading="Every company is required to have a registered office in Australia for the purpose of all the communications and notices, which ASIC must be advised of. A post office box cannot be used as a registered office of a company."
          />
          <div className="mt-5 ">
            <div className="flex flex-col gap-5">
              <CustomInput
                label="Care of (optional)"
                name="careOf"
                inputProps={{ type: "text" }}
              />
              <CustomInput
                label="Unit / Level   (optional)"
                name="careOf"
                inputProps={{ type: "text" }}
              />
              <div>
                <CustomInput
                  label="Street Address"
                  name="careOf"
                  inputProps={{ type: "text" }}
                />
              </div>
            </div>
          </div>
          <div className="mt-5 grid grid-cols-2">
            <SearchableDropdownExample />
            <p className="text-sm text-[#515151] max-w-2xl mt-2">
              Type few characters in suburb and then select from drop down list.
            </p>
          </div>
          <p className="text-sm text-gray-700">state</p>
          <p className="text-sm text-gray-700 mt-5">Post code</p>
          <div className="flex items-center gap-5 justify-between  max-w-md mt-8">
            <label className="text-sm text-gray-700">Country</label>
            <select
              value={companyType}
              onChange={(e) => setCompanyType(e.target.value)}
              className="border w-full max-w-sm focus:outline-none focus:ring-2 focus:ring-blue-300 px-4 py-2 shadow-sm text-gray-700"
            >
              <option value="" disabled></option>
              {companyOptions.map((option, idx) => (
                <option key={idx} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>
        </div>
      </form>
    </div>
  );
}

export default Form;
